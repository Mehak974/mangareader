/** @type {import('next').NextConfig} */
const nextConfig = {

  // ── 1. Image optimization ─────────────────────────────────────────────────
  // All manga images go through your CF Worker proxy, so list your worker domain.
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'mangareader-proxy.*.workers.dev' },
      { protocol: 'https', hostname: '*.yourdomain.com' },
      // Fallback (direct, before proxy is up):
      { protocol: 'https', hostname: '*.manganato.com' },
      { protocol: 'https', hostname: '*.mangakatana.com' },
      { protocol: 'https', hostname: 'uploads.mangadex.org' },
      { protocol: 'https', hostname: 's1.mkklcdnv6tempv2.com' },
    ],
    formats:       ['image/avif', 'image/webp'],
    minimumCacheTTL: 2592000, // 30 days
    deviceSizes:   [320, 480, 640, 750, 828, 1080],
    imageSizes:    [16, 32, 64, 96, 128, 192, 256],
  },

  // ── 2. Security headers ───────────────────────────────────────────────────
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-DNS-Prefetch-Control',   value: 'on' },
          { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
          { key: 'X-Frame-Options',           value: 'SAMEORIGIN' },
          { key: 'X-Content-Type-Options',    value: 'nosniff' },
          { key: 'Referrer-Policy',           value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy',         value: 'camera=(), microphone=(), geolocation=()' },
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-inline' 'unsafe-eval'",  // tighten after launch
              "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
              "img-src 'self' data: blob: https: *",              // images come from many CDNs
              "font-src 'self' https://fonts.gstatic.com",
              "connect-src 'self' https://graphql.anilist.co https://*.workers.dev wss:",
              "frame-ancestors 'self'",
            ].join('; '),
          },
        ],
      },
      // ── API routes: CORS for your worker ──────────────────────────────────
      {
        source: '/api/(.*)',
        headers: [
          { key: 'Access-Control-Allow-Origin',  value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type' },
        ],
      },
      // ── Chapter pages: long cache (content never changes) ─────────────────
      {
        source: '/manga/:slug/chapter/:num',
        headers: [
          { key: 'Cache-Control', value: 'public, s-maxage=86400, stale-while-revalidate=604800' },
        ],
      },
      // ── Manga detail: medium cache ─────────────────────────────────────────
      {
        source: '/manga/:slug',
        headers: [
          { key: 'Cache-Control', value: 'public, s-maxage=3600, stale-while-revalidate=86400' },
        ],
      },
    ];
  },

  // ── 3. Redirects ──────────────────────────────────────────────────────────
  async redirects() {
    return [
      { source: '/home',    destination: '/',          permanent: true },
      { source: '/index',   destination: '/',          permanent: true },
      // Force lowercase slugs
      { source: '/Manga/:slug', destination: '/manga/:slug', permanent: true },
    ];
  },

  // ── 4. Compression + performance ─────────────────────────────────────────
  compress:              true,
  poweredByHeader:       false,   // don't leak "X-Powered-By: Next.js"
  reactStrictMode:       true,
  swcMinify:             true,

  // ── 5. Experimental ───────────────────────────────────────────────────────
  experimental: {
    optimizeCss:       true,
    scrollRestoration: true,
  },
};

module.exports = nextConfig;
