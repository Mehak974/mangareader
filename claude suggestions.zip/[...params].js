/**
 * pages/api/chapter/[...params].js
 * GET /api/chapter/mangadex/<chapterId>
 * GET /api/chapter/manganato?url=<encoded>
 * GET /api/chapter/mangakatana?url=<encoded>
 * GET /api/chapter/mangaread?url=<encoded>
 * GET /api/chapter/auto?md=<id>&mnt=<url>&mkt=<url>&mr=<url>  ← fallback router
 *
 * Returns:  { pages: string[], source: string, cached: boolean }
 */

import {
  mdChapterPages,
  manganatoPages,
  mangakatanaPages,
  mangareadPages,
  getChapterPagesWithFallback,
} from '../../../lib/sources/index';

const CACHE_HEADERS = {
  'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=604800',
};

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).end();

  const [source, ...rest] = req.query.params || [];

  try {
    let pages = [];
    let sourceName = source;

    switch (source) {
      case 'mangadex': {
        const chapterId = rest[0];
        if (!chapterId) return res.status(400).json({ error: 'Missing chapterId' });
        const result = await mdChapterPages(chapterId);
        pages = result.pages;
        break;
      }

      case 'manganato': {
        const url = req.query.url;
        if (!url) return res.status(400).json({ error: 'Missing ?url=' });
        pages = await manganatoPages(decodeURIComponent(url));
        break;
      }

      case 'mangakatana': {
        const url = req.query.url;
        if (!url) return res.status(400).json({ error: 'Missing ?url=' });
        pages = await mangakatanaPages(decodeURIComponent(url));
        break;
      }

      case 'mangaread': {
        const url = req.query.url;
        if (!url) return res.status(400).json({ error: 'Missing ?url=' });
        pages = await mangareadPages(decodeURIComponent(url));
        break;
      }

      case 'auto': {
        // Priority fallback: MangaDex → Manganato → MangaKatana → MangaRead
        const result = await getChapterPagesWithFallback({
          mangadexChapterId: req.query.md,
          manganatoUrl:      req.query.mnt && decodeURIComponent(req.query.mnt),
          mangakatanaUrl:    req.query.mkt && decodeURIComponent(req.query.mkt),
          mangareadUrl:      req.query.mr  && decodeURIComponent(req.query.mr),
        });
        pages = result;
        sourceName = 'auto';
        break;
      }

      default:
        return res.status(400).json({ error: `Unknown source: ${source}` });
    }

    if (!pages.length) {
      return res.status(404).json({ error: 'No pages found', source: sourceName });
    }

    res.setHeader('Cache-Control', CACHE_HEADERS['Cache-Control']);
    return res.status(200).json({ pages, source: sourceName, count: pages.length });
  } catch (err) {
    console.error(`[/api/chapter/${source}]`, err);
    return res.status(502).json({ error: err.message, source });
  }
}
