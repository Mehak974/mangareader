/**
 * lib/sources/index.js
 * Unified source router with:
 * - Priority-based fallback (MangaDex first → Manganato → MangaKatana → MangaRead)
 * - Exponential backoff retry
 * - In-memory short-term cache (Next.js server)
 * - All requests go through your Cloudflare Worker proxy
 *
 * Set env:  WORKER_URL=https://mangareader-proxy.YOUR_SUBDOMAIN.workers.dev
 */

const WORKER = process.env.WORKER_URL || 'https://mangareader-proxy.your-subdomain.workers.dev';
const MEM_CACHE = new Map(); // In-memory cache (server-side, per instance)

// ─── Utils ────────────────────────────────────────────────────────────────────

function memGet(key) {
  const entry = MEM_CACHE.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expires) { MEM_CACHE.delete(key); return null; }
  return entry.value;
}

function memSet(key, value, ttlMs) {
  // Evict oldest if cache too large
  if (MEM_CACHE.size > 500) {
    const firstKey = MEM_CACHE.keys().next().value;
    MEM_CACHE.delete(firstKey);
  }
  MEM_CACHE.set(key, { value, expires: Date.now() + ttlMs });
}

async function withRetry(fn, retries = 3, delayMs = 500) {
  for (let attempt = 0; attempt < retries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (attempt === retries - 1) throw err;
      await new Promise(r => setTimeout(r, delayMs * Math.pow(2, attempt)));
    }
  }
}

// ─── Image URL proxying ───────────────────────────────────────────────────────

/**
 * Convert any source image URL to your proxied URL.
 * This is the KEY fix for all 403/hotlink blocks.
 */
export function proxyImageUrl(originalUrl) {
  if (!originalUrl) return '/placeholder.png';
  // Already proxied
  if (originalUrl.startsWith(WORKER)) return originalUrl;
  return `${WORKER}/img-proxy?url=${encodeURIComponent(originalUrl)}`;
}

/**
 * Proxy an array of chapter page images.
 */
export function proxyChapterPages(pages = []) {
  return pages.map(proxyImageUrl);
}

// ─── AniList ──────────────────────────────────────────────────────────────────

export async function anilistQuery(query, variables = {}) {
  const cacheKey = `al:${JSON.stringify({ query, variables })}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/anilist`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables }),
      next: { revalidate: 86400 }, // Next.js ISR: 24h
    })
  );

  if (!res.ok) throw new Error(`AniList error: ${res.status}`);
  const data = await res.json();
  memSet(cacheKey, data, 24 * 60 * 60 * 1000); // 24h
  return data;
}

export async function getMangaByTitle(title) {
  return anilistQuery(`
    query ($search: String) {
      Media(search: $search, type: MANGA, sort: SEARCH_MATCH) {
        id siteUrl status format episodes chapters
        title { romaji english native userPreferred }
        description(asHtml: false)
        coverImage { extraLarge large medium color }
        bannerImage
        genres tags { name }
        averageScore popularity
        startDate { year month day }
        endDate   { year month day }
        staff { nodes { name { full } } }
        characters(sort: ROLE, perPage: 6) {
          nodes {
            name { full }
            image { large }
          }
        }
      }
    }
  `, { search: title });
}

export async function getMangaById(anilistId) {
  return anilistQuery(`
    query ($id: Int) {
      Media(id: $id, type: MANGA) {
        id siteUrl status format chapters
        title { romaji english native userPreferred }
        description(asHtml: false)
        coverImage { extraLarge large medium color }
        bannerImage genres tags { name }
        averageScore popularity
        startDate { year month day }
        endDate   { year month day }
      }
    }
  `, { id: anilistId });
}

export async function getTrendingManga(page = 1, perPage = 20) {
  return anilistQuery(`
    query ($page: Int, $perPage: Int) {
      Page(page: $page, perPage: $perPage) {
        media(type: MANGA, sort: TRENDING_DESC) {
          id title { romaji english userPreferred }
          coverImage { large medium }
          genres averageScore
        }
      }
    }
  `, { page, perPage });
}

// ─── MangaDex (Official API — most reliable) ──────────────────────────────────

export async function mdSearch(title, { limit = 20, offset = 0 } = {}) {
  const qs = new URLSearchParams({ title, limit, offset, 'includes[]': 'cover_art' });
  const cacheKey = `md-search:${title}:${offset}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/mangadex/manga?${qs}`, {
      next: { revalidate: 3600 },
    })
  );
  const data = await res.json();
  memSet(cacheKey, data, 60 * 60 * 1000); // 1h
  return data;
}

export async function mdChapters(mangaId, { lang = 'en', offset = 0, limit = 96 } = {}) {
  const qs = new URLSearchParams({
    'translatedLanguage[]': lang,
    'order[chapter]': 'desc',
    limit, offset,
    'includes[]': 'scanlation_group',
  });
  const cacheKey = `md-chaps:${mangaId}:${lang}:${offset}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/mangadex/manga/${mangaId}/feed?${qs}`, {
      next: { revalidate: 600 }, // 10min
    })
  );
  const data = await res.json();
  memSet(cacheKey, data, 10 * 60 * 1000);
  return data;
}

export async function mdChapterPages(chapterId) {
  const cacheKey = `md-pages:${chapterId}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/mangadex/at-home/server/${chapterId}`, {
      next: { revalidate: 3600 },
    })
  );
  const data = await res.json();

  // Build image URLs and proxy them
  const { baseUrl, chapter: { hash, data: pages } } = data;
  const imageUrls = proxyChapterPages(pages.map(p => `${baseUrl}/data/${hash}/${p}`));
  const result = { pages: imageUrls, dataSaver: proxyChapterPages(
    (data.chapter.dataSaver || []).map(p => `${baseUrl}/data-saver/${hash}/${p}`)
  )};

  memSet(cacheKey, result, 60 * 60 * 1000);
  return result;
}

// ─── Manganato ────────────────────────────────────────────────────────────────

export async function manganatoPages(chapterUrl) {
  const cacheKey = `mnt:${chapterUrl}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/manganato?url=${encodeURIComponent(chapterUrl)}`, {
      next: { revalidate: 86400 },
    })
  );
  const { html } = await res.json();

  // Parse image URLs from Manganato HTML
  const imgRegex = /class="container-chapter-reader"[\s\S]*?<img[^>]+src="([^"]+)"/g;
  const pages = [];
  let match;
  while ((match = imgRegex.exec(html)) !== null) {
    pages.push(proxyImageUrl(match[1]));
  }

  memSet(cacheKey, pages, 24 * 60 * 60 * 1000);
  return pages;
}

export async function manganatoChapterList(mangaUrl) {
  const cacheKey = `mnt-list:${mangaUrl}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/manganato?url=${encodeURIComponent(mangaUrl)}`, {
      next: { revalidate: 1800 },
    })
  );
  const { html } = await res.json();

  // Parse chapter list
  const chapterRegex = /<a[^>]+href="(https:\/\/(?:chapmanganato|readmanganato)[^"]+)"[^>]*>([^<]+)<\/a>/g;
  const chapters = [];
  let match;
  while ((match = chapterRegex.exec(html)) !== null) {
    chapters.push({ url: match[1], title: match[2].trim() });
  }

  memSet(cacheKey, chapters, 30 * 60 * 1000);
  return chapters;
}

// ─── MangaKatana ──────────────────────────────────────────────────────────────

export async function mangakatanaPages(chapterUrl) {
  const cacheKey = `mkt:${chapterUrl}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/mangakatana?url=${encodeURIComponent(chapterUrl)}`, {
      next: { revalidate: 86400 },
    })
  );
  const { html } = await res.json();

  // MangaKatana stores images in a JS variable: var ytaw=['url1','url2',...]
  const scriptMatch = html.match(/var ytaw=(\[[^\]]+\])/);
  if (!scriptMatch) return [];

  const rawUrls = JSON.parse(scriptMatch[1]);
  const pages = proxyChapterPages(rawUrls);

  memSet(cacheKey, pages, 24 * 60 * 60 * 1000);
  return pages;
}

// ─── MangaRead ────────────────────────────────────────────────────────────────

export async function mangareadPages(chapterUrl) {
  const cacheKey = `mr:${chapterUrl}`;
  const cached = memGet(cacheKey);
  if (cached) return cached;

  const res = await withRetry(() =>
    fetch(`${WORKER}/api/mangaread?url=${encodeURIComponent(chapterUrl)}`, {
      next: { revalidate: 86400 },
    })
  );
  const { html } = await res.json();

  // MangaRead typically uses WordPress Comic plugins
  const imgRegex = /<img[^>]+class="[^"]*wp-manga-chapter-img[^"]*"[^>]+src="([^"]+)"/g;
  const pages = [];
  let match;
  while ((match = imgRegex.exec(html)) !== null) {
    pages.push(proxyImageUrl(match[1]));
  }

  memSet(cacheKey, pages, 24 * 60 * 60 * 1000);
  return pages;
}

// ─── Priority Fallback Router ─────────────────────────────────────────────────
/**
 * Try sources in order; return first successful result.
 * Use this for chapter images when you have multiple source URLs.
 */
export async function getChapterPagesWithFallback(sources = {}) {
  const {
    mangadexChapterId,
    manganatoUrl,
    mangakatanaUrl,
    mangareadUrl,
  } = sources;

  const attempts = [
    mangadexChapterId  && (() => mdChapterPages(mangadexChapterId)),
    manganatoUrl       && (() => manganatoPages(manganatoUrl)),
    mangakatanaUrl     && (() => mangakatanaPages(mangakatanaUrl)),
    mangareadUrl       && (() => mangareadPages(mangareadUrl)),
  ].filter(Boolean);

  for (const attempt of attempts) {
    try {
      const pages = await attempt();
      if (pages && pages.length > 0) return pages;
    } catch (err) {
      console.warn('[source fallback]', err.message);
    }
  }

  throw new Error('All sources failed for this chapter.');
}
