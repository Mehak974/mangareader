/**
 * pages/sitemap.xml.js
 * Dynamic XML sitemap — covers every manga + chapter page.
 * Critical for SEO: Google must discover ALL your chapter URLs.
 *
 * Access: GET /sitemap.xml
 * Submit at: https://search.google.com/search-console
 *
 * Split into multiple sitemaps if > 50,000 URLs:
 *   /sitemap-index.xml  →  /sitemap-manga.xml  +  /sitemap-chapters.xml
 */

const SITE_URL = 'https://yourdomain.com'; // ← Change this

function url(loc, { lastmod, changefreq = 'weekly', priority = 0.7 } = {}) {
  return `  <url>
    <loc>${SITE_URL}${loc}</loc>
    ${lastmod ? `<lastmod>${lastmod}</lastmod>` : ''}
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`;
}

export async function getServerSideProps({ res }) {
  // ── Fetch your manga list from your DB / API ──────────────────────────────
  // Replace this with your actual data source.
  // Example shape: [{ slug, updatedAt, chapters: [{ number }] }]
  let mangaList = [];
  try {
    // e.g. from your DB:
    // mangaList = await prisma.manga.findMany({ select: { slug, updatedAt, chapters } })
    // or from an API:
    // const r = await fetch(`${SITE_URL}/api/manga/list`); mangaList = await r.json();
  } catch {
    mangaList = [];
  }

  const today = new Date().toISOString().split('T')[0];

  const staticUrls = [
    url('/', { changefreq: 'daily', priority: 1.0, lastmod: today }),
    url('/latest',  { changefreq: 'daily',  priority: 0.9 }),
    url('/popular', { changefreq: 'weekly', priority: 0.8 }),
    url('/completed', { changefreq: 'weekly', priority: 0.7 }),
    // Genre pages
    ...[
      'Action','Adventure','Comedy','Drama','Fantasy','Horror','Isekai',
      'Manhwa','Manhua','Mystery','Romance','Sci-Fi','Seinen','Shounen',
      'Shoujo','Slice of Life','Sports','Supernatural','Thriller','Yaoi','Yuri',
    ].map(g => url(`/genre/${g.toLowerCase().replace(/ /g,'-')}`, {
      changefreq: 'weekly', priority: 0.7,
    })),
  ];

  const mangaUrls = mangaList.flatMap(manga => {
    const lastmod = manga.updatedAt
      ? new Date(manga.updatedAt).toISOString().split('T')[0]
      : today;

    const mangaPageUrl = url(`/manga/${manga.slug}`, {
      changefreq: 'daily',
      priority:   0.8,
      lastmod,
    });

    const chapterUrls = (manga.chapters || []).map(ch =>
      url(`/manga/${manga.slug}/chapter/${ch.number}`, {
        changefreq: 'monthly',
        priority:   0.6,
        lastmod,
      })
    );

    return [mangaPageUrl, ...chapterUrls];
  });

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset
  xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
    http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
${[...staticUrls, ...mangaUrls].join('\n')}
</urlset>`;

  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.setHeader('Cache-Control', 'public, s-maxage=3600, stale-while-revalidate=7200');
  res.write(sitemap);
  res.end();

  return { props: {} };
}

export default function Sitemap() { return null; }
