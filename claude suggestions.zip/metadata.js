/**
 * lib/seo/metadata.js
 * SEO + GEO + AEO for manga reader
 *
 * SEO  — Google/Bing search rankings
 * GEO  — Generative Engine Optimization (ChatGPT, Perplexity, Claude answers)
 * AEO  — Answer Engine Optimization (Google Featured Snippets, People Also Ask)
 */

const SITE_NAME  = 'MangaReader'; // ← Change to your site name
const SITE_URL   = 'https://yourdomain.com'; // ← Change to your domain
const SITE_DESC  = 'Read manga online free — latest chapters, top series, and new releases daily.';

// ─── Base metadata (all pages) ────────────────────────────────────────────────

export function baseMeta() {
  return {
    metadataBase: new URL(SITE_URL),
    authors: [{ name: SITE_NAME }],
    robots: { index: true, follow: true },
    alternates: { canonical: SITE_URL },
    openGraph: {
      siteName: SITE_NAME,
      locale: 'en_US',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      site: '@yourtwitterhandle',
    },
    verification: {
      google: 'YOUR_GOOGLE_SITE_VERIFICATION',
    },
  };
}

// ─── Manga detail page (/manga/[slug]) ────────────────────────────────────────

export function mangaMeta(manga, slug) {
  const title       = manga?.title?.english || manga?.title?.romaji || manga?.title?.userPreferred;
  const altTitle    = manga?.title?.romaji !== title ? manga?.title?.romaji : null;
  const description = manga?.description
    ? stripHtml(manga.description).slice(0, 320)
    : `Read ${title} manga online free. ${manga?.chapters ?? '???'} chapters available.`;

  const canonical = `${SITE_URL}/manga/${slug}`;
  const status    = manga?.status === 'FINISHED' ? 'Completed' : 'Ongoing';
  const genres    = (manga?.genres || []).slice(0, 5).join(', ');

  return {
    title: `Read ${title} Manga Online Free | ${SITE_NAME}`,
    description,
    keywords: [
      `${title} manga`,
      `read ${title} online`,
      `${title} manga free`,
      altTitle && `${altTitle} manga`,
      `${title} chapters`,
      genres,
    ].filter(Boolean).join(', '),
    alternates: { canonical },
    openGraph: {
      title: `${title} | Read Free on ${SITE_NAME}`,
      description,
      url: canonical,
      type: 'book',
      images: manga?.coverImage?.extraLarge
        ? [{ url: manga.coverImage.extraLarge, width: 460, height: 660, alt: `${title} cover` }]
        : [],
    },
    twitter: {
      title: `Read ${title} — Free Manga`,
      description: `${status} · ${manga?.chapters ?? '???'} chapters · ${genres}`,
      images: manga?.coverImage?.large ? [manga.coverImage.large] : [],
    },
    other: {
      'geo.region': 'US',
      'og:book:author': (manga?.staff?.nodes || []).map(n => n.name.full).join(', '),
      'og:book:tag': (manga?.genres || []).join(','),
    },
  };
}

// ─── Chapter page (/manga/[slug]/chapter/[num]) ───────────────────────────────

export function chapterMeta(manga, chapterNumber, slug) {
  const title    = manga?.title?.english || manga?.title?.romaji;
  const canonical = `${SITE_URL}/manga/${slug}/chapter/${chapterNumber}`;

  return {
    title: `${title} Chapter ${chapterNumber} | Read Free — ${SITE_NAME}`,
    description: `Read ${title} Chapter ${chapterNumber} online for free. Fast loading, no ads.`,
    keywords: `${title} chapter ${chapterNumber}, read ${title} ch ${chapterNumber} online, ${title} manga`,
    alternates: { canonical },
    robots: { index: true, follow: true },
    openGraph: {
      title:       `${title} — Chapter ${chapterNumber}`,
      description: `Read Chapter ${chapterNumber} of ${title} for free on ${SITE_NAME}.`,
      url:         canonical,
      type:        'article',
      images:      manga?.coverImage?.medium ? [manga.coverImage.medium] : [],
    },
  };
}

// ─── Genre page (/genre/[name]) ───────────────────────────────────────────────

export function genreMeta(genre) {
  const canonical = `${SITE_URL}/genre/${genre.toLowerCase()}`;
  return {
    title: `Best ${genre} Manga — Read Free Online | ${SITE_NAME}`,
    description: `Discover the best ${genre} manga. Read popular and new ${genre} manga for free with fast image loading and no registration needed.`,
    keywords: `${genre} manga, best ${genre} manga online, read ${genre} manga free`,
    alternates: { canonical },
    openGraph: {
      title: `Top ${genre} Manga — ${SITE_NAME}`,
      description: `Browse ${genre} manga — updated daily with new chapters.`,
      url: canonical,
    },
  };
}

// ─── Homepage ─────────────────────────────────────────────────────────────────

export function homeMeta() {
  return {
    title: `${SITE_NAME} — Read Manga Online Free | Latest Chapters Updated Daily`,
    description: SITE_DESC,
    keywords: 'read manga online free, manga reader, latest manga chapters, free manga, manga online',
    alternates: { canonical: SITE_URL },
    openGraph: {
      title:       `${SITE_NAME} — Read Manga Free`,
      description: SITE_DESC,
      url:         SITE_URL,
    },
  };
}

// ─── JSON-LD Structured Data ─────────────────────────────────────────────────
// Helps Google featured snippets + AI knowledge graphs (GEO/AEO)

export function mangaJsonLd(manga, slug, chapters = []) {
  const title  = manga?.title?.english || manga?.title?.romaji;
  const url    = `${SITE_URL}/manga/${slug}`;
  const status = manga?.status === 'FINISHED' ? 'Completed' : 'Ongoing';

  const base = {
    '@context': 'https://schema.org',
    '@type':    'Book',
    name:       title,
    alternateName: [manga?.title?.romaji, manga?.title?.native].filter(Boolean),
    description: manga?.description ? stripHtml(manga.description).slice(0, 500) : undefined,
    url,
    image:       manga?.coverImage?.extraLarge,
    genre:       manga?.genres || [],
    bookFormat:  'https://schema.org/GraphicNovel',
    numberOfPages: manga?.chapters,
    inLanguage:  'ja',
    workExample: chapters.slice(0, 10).map((ch, i) => ({
      '@type':      'Book',
      name:         `${title} Chapter ${ch.number || i + 1}`,
      url:          `${url}/chapter/${ch.number || i + 1}`,
      bookFormat:   'https://schema.org/GraphicNovel',
    })),
    // AEO: FAQ section — answers common "is X completed" questions
    mainEntity: {
      '@type': 'FAQPage',
      mainEntity: [
        {
          '@type': 'Question',
          name:    `Is ${title} completed or ongoing?`,
          acceptedAnswer: {
            '@type': 'Answer',
            text:    `${title} is currently ${status}. It has ${manga?.chapters ?? 'an unknown number of'} chapters.`,
          },
        },
        {
          '@type': 'Question',
          name:    `Where can I read ${title} online for free?`,
          acceptedAnswer: {
            '@type': 'Answer',
            text:    `You can read ${title} online for free on ${SITE_NAME} at ${url}.`,
          },
        },
        {
          '@type': 'Question',
          name:    `How many chapters does ${title} have?`,
          acceptedAnswer: {
            '@type': 'Answer',
            text:    `${title} has ${manga?.chapters ?? 'an unknown number of'} chapters.`,
          },
        },
      ],
    },
  };

  return JSON.stringify(base);
}

export function websiteJsonLd() {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type':    'WebSite',
    name:       SITE_NAME,
    url:        SITE_URL,
    potentialAction: {
      '@type':       'SearchAction',
      target:        `${SITE_URL}/search?q={search_term_string}`,
      'query-input': 'required name=search_term_string',
    },
    description: SITE_DESC,
  });
}

export function breadcrumbJsonLd(crumbs = []) {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type':    'BreadcrumbList',
    itemListElement: crumbs.map((crumb, i) => ({
      '@type':   'ListItem',
      position:  i + 1,
      name:      crumb.name,
      item:      `${SITE_URL}${crumb.href}`,
    })),
  });
}

// ─── Dynamic Sitemap helpers (use in pages/sitemap.xml.js) ───────────────────

export function generateSitemapEntry({ url, lastmod, changefreq = 'weekly', priority = 0.7 }) {
  return `  <url>
    <loc>${SITE_URL}${url}</loc>
    <lastmod>${lastmod || new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`;
}

export function generateSitemap(entries) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${entries.map(generateSitemapEntry).join('\n')}
</urlset>`;
}

// ─── GEO (Generative Engine Optimization) Content Tips ───────────────────────
// These are guidelines for your manga detail page content.
// AI systems (ChatGPT, Claude, Perplexity) index well-structured factual text.
//
// ✅ Include on every manga page:
//   - Clear paragraph: "X is a [genre] manga by [author], serialized in [magazine] since [year]."
//   - Status: "The series is [completed/ongoing] with [N] chapters."
//   - Synopsis: 3–5 sentence plain-text description (no HTML)
//   - FAQ section (rendered visibly, not just JSON-LD)
//   - Related manga section
//
// ✅ Page title format that wins AI citations:
//   "[Manga Name] — Read Online Free | [Site Name]"
//
// ✅ AEO winning patterns:
//   H2: "About [Manga Name]"
//   H3: "Is [Manga Name] complete?"  → immediate answer in the following <p>
//   H3: "How many chapters?"         → immediate answer
//   H3: "When was [Manga] released?" → immediate answer

// ─── Utils ────────────────────────────────────────────────────────────────────

function stripHtml(html) {
  return html.replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#039;/g, "'").trim();
}
