/**
 * middleware.js — Next.js Edge Middleware
 * Runs on Vercel's edge network (closest to user, ~0ms latency)
 *
 * Features:
 * - Rate limiting (60 API req/min per IP)
 * - Bot filtering
 * - Canonical redirect (www → non-www)
 * - Security headers
 */

import { NextResponse } from 'next/server';

// Simple in-memory rate limit (per Worker instance)
// For production at scale, use Upstash Redis:
// https://upstash.com/docs/redis/sdks/ratelimit-ts/overview
const RATE_MAP = new Map();

function checkRateLimit(ip, limit = 60, windowMs = 60000) {
  const now    = Date.now();
  const key    = `${ip}:${Math.floor(now / windowMs)}`;
  const count  = (RATE_MAP.get(key) || 0) + 1;
  RATE_MAP.set(key, count);

  // Cleanup old keys periodically
  if (RATE_MAP.size > 10000) {
    const cutoff = Math.floor(now / windowMs) - 2;
    for (const k of RATE_MAP.keys()) {
      if (parseInt(k.split(':')[1]) < cutoff) RATE_MAP.delete(k);
    }
  }

  return count <= limit;
}

const BAD_BOTS = [
  'scrapy', 'python-requests', 'curl/', 'wget/',
  'go-http-client', 'libwww', 'Jakarta',
];

export function middleware(req) {
  const { pathname, hostname } = req.nextUrl;
  const ip  = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const ua  = req.headers.get('user-agent') || '';

  // ── 1. Block known bad bots ──────────────────────────────────────────────
  const isBadBot = BAD_BOTS.some(b => ua.toLowerCase().includes(b.toLowerCase()));
  if (isBadBot && pathname.startsWith('/api/')) {
    return new NextResponse('Forbidden', { status: 403 });
  }

  // ── 2. Rate limit API routes ─────────────────────────────────────────────
  if (pathname.startsWith('/api/')) {
    const allowed = checkRateLimit(ip, 60, 60000); // 60 req/min
    if (!allowed) {
      return NextResponse.json(
        { error: 'Too many requests. Please slow down.' },
        { status: 429, headers: { 'Retry-After': '60' } }
      );
    }
  }

  // ── 3. www → non-www canonical redirect ──────────────────────────────────
  if (hostname.startsWith('www.')) {
    const url = req.nextUrl.clone();
    url.hostname = hostname.replace('www.', '');
    return NextResponse.redirect(url, 301);
  }

  // ── 4. Security headers on all responses ─────────────────────────────────
  const res = NextResponse.next();
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('X-Frame-Options', 'SAMEORIGIN');
  res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');

  return res;
}

export const config = {
  // Run on all routes except static files and Next internals
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|jpg|jpeg|gif|svg|ico|webp|woff2?|ttf|eot)).*)',
  ],
};
