# MangaReader — Complete Scale Guide
## From 1.5k → 100k Daily Visitors

---

## 1. WHY YOU KEEP GETTING BLOCKED (Root Cause + Fixes)

### Root Causes

| Source | Why It Blocks You | Fix |
|---|---|---|
| Manganato | Missing `Referer` header from their own domain | Send `Referer: https://manganato.com/` |
| MangaKatana | Missing `Referer` + UA mismatch | Send `Referer: https://mangakatana.com/` + Chrome UA |
| MangaRead | Hotlink protection on images | Proxy images through your CF Worker |
| AniList | 90 req/min rate limit hit by concurrent users | Cache ALL AniList responses 24h |
| MangaDex CDN | Requires Referer from mangadex.org | Set Referer: https://mangadex.org/ |

### The Permanent Fix: Cloudflare Worker Proxy

```
Before (broken):
User → Your Server → [blocked] Source

After (fixed):
User → Cloudflare CDN → Your Worker (adds Referer + UA) → Source
                ↑ 95% of requests served from Cloudflare cache
```

All the code is in `cloudflare/worker.js`. Deploy it once — it fixes everything.

### Deploy the Worker (5 minutes)

```bash
npm install -g wrangler
wrangler login

# Create KV namespace (free cache storage)
wrangler kv:namespace create CACHE
# Copy the ID it prints → paste in wrangler.toml

# Deploy
cd cloudflare
wrangler deploy
```

Then set in your `.env.local`:
```
WORKER_URL=https://mangareader-proxy.YOUR_SUBDOMAIN.workers.dev
```

---

## 2. MINIMIZE REQUESTS · IMPROVE SECURITY · REDUCE BANDWIDTH

### Caching Architecture (Multi-Layer)

```
Layer 1 — Cloudflare CDN          Free, global, ~0ms
           Images: 1 year (immutable)
           Chapter pages: 24h
           Manga detail: 1h

Layer 2 — Next.js ISR             Vercel edge, per region
           Manga pages: revalidate 3600 (1h)
           Chapter pages: revalidate 86400 (24h)

Layer 3 — Cloudflare KV           Free 100k reads/day
           AniList responses: 24h TTL
           MangaDex feeds: 10min TTL
           Scraped HTML: 30min TTL

Layer 4 — In-memory (Node.js)     Per server instance
           Hot data: 500 entries max, LRU
```

### Bandwidth Math at 100k visitors/day

```
Without caching:
  1M pages × 5MB avg (images) = 5TB/day ← IMPOSSIBLE on free

With your proxy + CDN:
  Cache hit rate: ~97% (manga images are identical per chapter)
  Origin fetches: 1M × 3% = 30k requests/day
  Origin bandwidth: 30k × 5MB = 150GB/day ← manageable
  Edge bandwidth served: 5TB/day ← free on Cloudflare
```

### Security Improvements

1. **Rate limiting on your API** (add to your Next.js middleware):

```javascript
// middleware.js
import { NextResponse } from 'next/server';

const RATE_LIMIT = new Map();

export function middleware(req) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown';
  const key = `${ip}:${Math.floor(Date.now() / 60000)}`; // per minute window
  
  const count = (RATE_LIMIT.get(key) || 0) + 1;
  RATE_LIMIT.set(key, count);
  
  // Clean old entries every 5min
  if (count === 1) setTimeout(() => RATE_LIMIT.delete(key), 60000);
  
  if (req.nextUrl.pathname.startsWith('/api/') && count > 60) {
    return NextResponse.json({ error: 'Rate limit exceeded' }, { status: 429 });
  }
  
  return NextResponse.next();
}

export const config = { matcher: ['/api/:path*'] };
```

2. **Hotlink protection** on your own images (Cloudflare → Security → Hotlink Protection)
3. **DDoS protection** — enabled automatically by Cloudflare free tier
4. **Bot filtering** — Cloudflare Bot Fight Mode (free)

### Bandwidth Optimization

```javascript
// Add to your chapter reader component:
// 1. Lazy load images below the fold
<img loading="lazy" decoding="async" src={proxyImageUrl(page)} />

// 2. Preload next chapter
useEffect(() => {
  if (currentPage > totalPages - 3) {
    router.prefetch(`/manga/${slug}/chapter/${nextChapter}`);
  }
}, [currentPage]);

// 3. Use Next/Image with blur placeholder for covers
import Image from 'next/image';
<Image
  src={manga.coverImage.large}
  placeholder="blur"
  blurDataURL="data:image/jpeg;base64,/9j/..."
  quality={85}
/>
```

---

## 3. FREE PLATFORM STACK

### Recommended Stack (Entirely Free to $0 until ~50k DAU)

| Service | Purpose | Free Tier | Paid if needed |
|---|---|---|---|
| **Vercel** | Frontend (Next.js) | 100GB BW, unlimited deploys | $20/mo Pro |
| **Cloudflare Workers** | API + Image proxy | 100k req/day | $5/mo for 10M |
| **Cloudflare KV** | Cache storage | 100k reads/day | $0.50/M reads |
| **Cloudflare Pages** | Alternative frontend | Unlimited BW | - |
| **Cloudflare CDN** | Global CDN + DDoS | Free forever | - |
| **Neon.tech** | Postgres DB (bookmarks etc.) | 0.5GB free | $19/mo |
| **Upstash Redis** | Session/hot cache | 10k cmd/day | $0.20/100k |
| **Railway** | Backend if needed | $5 credit/mo | $5/mo |

### Architecture Diagram

```
Users worldwide
     │
     ▼
Cloudflare (CDN + DDoS + Bot Filter)   ← FREE, automatic
     │
     ├── Static assets → Cloudflare Cache (99% hit rate)
     │
     ├── Pages → Vercel Edge (ISR)      ← FREE 100GB/mo
     │              │
     │              └── Cache miss → Your Next.js server
     │                                     │
     └── /img-proxy, /api/proxy →  Cloudflare Workers   ← FREE 100k/day
                                           │
                                    Cloudflare KV cache  ← FREE 100k reads
                                           │
                                    (cache miss only)
                                           │
                    ┌──────────────────────┼────────────────────┐
                    │                      │                    │
               AniList API          MangaDex API         Manganato/MangaKatana
               (24h cached)        (official, stable)    (30min cached + proper headers)
```

### Environment Variables

```bash
# .env.local
WORKER_URL=https://mangareader-proxy.YOUR_SUBDOMAIN.workers.dev
NEXT_PUBLIC_SITE_URL=https://yourdomain.com
NEXT_PUBLIC_SITE_NAME=MangaReader

# Optional (for bookmarks/user features)
DATABASE_URL=postgresql://...
```

### Deploy to Vercel + Cloudflare

```bash
# 1. Push to GitHub
git push origin main

# 2. Connect to Vercel
# → vercel.com → New Project → Import your GitHub repo
# → Framework: Next.js → Deploy

# 3. Add custom domain in Vercel
# → Settings → Domains → Add your domain

# 4. In Cloudflare DNS:
#    A record: yourdomain.com → Vercel IP (from Vercel dashboard)
#    CNAME:    www → cname.vercel-dns.com
#    Proxy: ✅ ON (orange cloud = Cloudflare CDN active)

# 5. Deploy worker
cd cloudflare && wrangler deploy
```

---

## 4. REACH 10,000 USERS IN 15 DAYS

### Current State
- Daily visitors: 1,300–1,500
- Goal: 10,000 (6.7× growth)
- Timeline: 15 days

### Day-by-Day Plan

#### Days 1–3: Fix & Prepare
- [ ] Deploy Cloudflare Worker (zero more blocking)
- [ ] Fix all broken chapters users reported
- [ ] Add a "Report broken chapter" button (builds trust)
- [ ] Set up Google Search Console + submit sitemap
- [ ] Set up Google Analytics 4

#### Days 4–6: Reddit Launch
Post to these subreddits (one per day, different posts):

| Subreddit | Subscribers | Best post type |
|---|---|---|
| r/manga | 3.8M | "I built a free manga reader — no ads" |
| r/manhwa | 800k | Feature specific manhwa series |
| r/manhua | 200k | Feature manhua content |
| r/anime | 4M | For manga adaptations of anime |
| r/OnePiece | 1.2M | "Read OP free — all X chapters" |
| r/Naruto | 600k | Same angle |
| r/Berserk | 400k | Same |

**Reddit post template:**
```
Title: I built a manga reader with [feature they care about]

Body:
Been reading manga for years and was frustrated with [specific pain point].
So I built [YourSite].

What makes it different:
• [Specific feature #1]
• [Specific feature #2]  
• Zero ads, zero account required

Currently has [X] manga series and updates daily.

Link: [yourdomain.com]

Happy to hear feedback and add requested series!
```

#### Days 7–9: Discord Servers
Join and share in these Discord servers (check rules first):

- Manga Paradise
- MangaDex Community
- Manga/Anime Discord servers for specific popular series
- Share your site in #recommendations channels

**Discord pitch (1 sentence):**
> "Made a free manga reader with fast image loading and all [popular series] chapters — [yourdomain.com]"

#### Days 10–12: Twitter/X + TikTok
- Twitter: Tweet daily about newly added chapters tagging popular manga names
- TikTok: Short clips showing your reader's features — manga community is huge on TikTok
- Tag: #manga #manhwa #mangareader #readmangaonline

**Sample tweet:**
> "One Piece Chapter 1100 is now on [yourdomain.com] — fast reader, no ads, free forever 📖 #manga #OnePiece"

#### Days 13–15: SEO Quick Wins
- Search: "read [popular manga] online free" — are you ranking?
- Add chapter update schema markup (Google indexes fast)
- Create 5 genre landing pages optimized for "[genre] manga"

### Content That Drives Repeat Visitors
1. **Latest Updates page** — shows new chapters (reason to return daily)
2. **Reading history** (localStorage, no account needed)
3. **Continue Reading** on homepage
4. **Discord server** for your site — community = retention

### Retention Math
```
10k visitors × 40% return rate = 4k daily regulars
4k regulars × 10 pages = 40k page views/day
New visitors × SEO = continuous growth

To reach 100k: repeat this playbook × 10 + SEO compound interest
```

---

## 5. SEO + GEO + AEO

### SEO (Google/Bing Rankings)

**Highest-priority pages:**
```
Priority 1: /manga/[popular-series]
  → Target: "read one piece online free"
  → Volume: 50k+/month

Priority 2: /manga/[series]/chapter/[latest]
  → Target: "one piece chapter 1100 read online"
  → Volume: 10k+/month per new chapter

Priority 3: /genre/[genre]
  → Target: "best isekai manga online"
  → Volume: varies

Priority 4: /latest
  → Target: "manga latest chapters today"
```

**On-page SEO checklist per manga:**
- [ ] Title: `Read [Name] Manga Online Free | [Site]`
- [ ] Description: mentions chapter count, status, genres
- [ ] H1: `[Manga Name]`  
- [ ] H2: `About [Manga Name]` / `Chapters` / `Similar Manga`
- [ ] Alt text on cover: `[Manga Name] manga cover`
- [ ] Breadcrumb: Home → Manga → [Name]
- [ ] JSON-LD: Book + FAQ schema (see `lib/seo/metadata.js`)
- [ ] Canonical URL set
- [ ] Internal links to genre pages

**Technical SEO:**
- [ ] Sitemap submitted to Google Search Console
- [ ] Core Web Vitals all green (LCP < 2.5s, CLS < 0.1, FID < 100ms)
- [ ] Mobile-first (manga readers are 80%+ mobile)
- [ ] Page speed: images lazy-loaded, no render-blocking JS

### GEO (Generative Engine Optimization — ChatGPT, Claude, Perplexity)

These AI systems cite authoritative sources when users ask "where can I read X".
To get cited:

1. **Write factual summaries** on each manga page:
   ```
   "[Title] is a [genre] manga/manhwa/manhua by [author], 
   serialized in [publication] since [year]. The series has 
   [X] chapters and is currently [ongoing/completed]."
   ```

2. **FAQ section** (visible on page, not just JSON-LD):
   - "Is [Title] completed?"
   - "Where can I read [Title] online for free?"
   - "How many chapters does [Title] have?"

3. **Consistent citation format** — mention your site name + URL in:
   - About page
   - All press/link mentions
   - Alt text, meta tags

4. **Authority signals**:
   - Get listed on manga databases (MyAnimeList discussion threads)
   - Reddit posts linking to your site
   - Discord mentions

### AEO (Answer Engine Optimization — Featured Snippets)

Google shows featured snippets for questions with clear, direct answers.

**Target questions:**
```
"Is [manga] completed?" → immediate answer in first sentence
"How many chapters does [manga] have?" → "[Title] has [N] chapters."
"Where can I read [manga]?" → your site appears
"[Manga] chapter [N] release date" → your chapter pages
```

**Implementation:**
```html
<!-- On manga page, add a visible FAQ section -->
<section class="manga-faq">
  <h2>Frequently Asked Questions</h2>
  
  <div class="faq-item">
    <h3>Is {title} completed?</h3>
    <p>{title} is currently {status}. The series has {chapters} chapters 
    as of {date}.</p>
  </div>
  
  <div class="faq-item">
    <h3>Where can I read {title} online for free?</h3>
    <p>You can read all {chapters} chapters of {title} online for free 
    on {SITE_NAME} at {SITE_URL}/manga/{slug}.</p>
  </div>
  
  <div class="faq-item">
    <h3>How many chapters does {title} have?</h3>
    <p>{title} has {chapters} chapters{ongoing ? ', with new chapters 
    added regularly' : ', and the series is complete'}.</p>
  </div>
</section>
```

---

## 6. SOURCES CONFIGURATION REFERENCE

### MangaDex (Priority #1 — Official API)
- API: `https://api.mangadex.org`
- No scraping, no blocks, official documentation
- Rate limit: 5 req/sec (handled by Worker + KV cache)
- Chapter images: via `at-home/server/{chapterId}` → CDN network
- **USE THIS AS PRIMARY SOURCE whenever possible**

### AniList (Metadata only)
- GraphQL: `https://graphql.anilist.co`
- Rate limit: 90 req/min per IP (fixed by Worker caching 24h)
- Best for: cover art, genres, description, status, score
- **Never query per-user-request; always serve from cache**

### Manganato / ReadManganato / ChapManganato
- Fix: `Referer: https://manganato.com/` on ALL requests (images + HTML)
- Image CDN domains: `*.mkklcdnv6tempv2.com`, `*.mkklcdnv6temp.com`
- Cache chapter HTML: 30min (chapters don't change)
- Cache images: 1 year (immutable)

### MangaKatana
- Fix: `Referer: https://mangakatana.com/`
- Images: `xfs.mangakatana.com` — needs Referer
- Pages stored in JS variable `var ytaw=[...]` in HTML source
- Cache 30min HTML, 1 year images

### MangaRead.org
- Fix: `Referer: https://mangaread.org/`
- WordPress + WP-Manga plugin structure
- Images in `wp-manga-chapter-img` class
- Cache 30min HTML, 1 year images

---

## QUICK START CHECKLIST

```
Day 1:
□ Deploy Cloudflare Worker (cloudflare/worker.js)
□ Create KV namespace, update wrangler.toml
□ Update WORKER_URL in your .env
□ Replace image URLs with proxyImageUrl() calls
□ Deploy to Vercel

Day 2:
□ Add manga JSON-LD schema to manga pages
□ Submit sitemap to Google Search Console
□ Add FAQ sections to top 20 manga pages

Day 3+:
□ Post to Reddit (r/manga, r/manhwa)
□ Set up Discord community
□ Monitor Google Search Console for indexed pages
□ Check Core Web Vitals in PageSpeed Insights
```

---

## MONITORING (Free)

| Tool | What to monitor |
|---|---|
| Google Search Console | Indexed pages, clicks, impressions |
| Cloudflare Analytics | Traffic, cache hit rate, bandwidth saved |
| Vercel Analytics | Page performance, Web Vitals |
| UptimeRobot (free) | Site uptime alerts |
| Google Analytics 4 | User behavior, top manga, retention |
